using System;
using System.Drawing;
using System.Windows.Forms;

namespace Lab1WinForms
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new LoginForm());
        }
    }

    public class LoginForm : Form
    {
        private readonly TextBox txtUsername = new TextBox();
        private readonly TextBox txtPassword = new TextBox();

        public LoginForm()
        {
            Text = "Login Form";
            ClientSize = new Size(420, 280);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            Label title = new Label
            {
                Text = "LOGIN FORM",
                Font = new Font("Arial", 16, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(20, 20),
                Size = new Size(380, 35)
            };

            Label lblUsername = new Label
            {
                Text = "Username:",
                Location = new Point(35, 85),
                Size = new Size(100, 25)
            };

            txtUsername.Location = new Point(145, 82);
            txtUsername.Size = new Size(230, 25);

            Label lblPassword = new Label
            {
                Text = "Password:",
                Location = new Point(35, 125),
                Size = new Size(100, 25)
            };

            txtPassword.Location = new Point(145, 122);
            txtPassword.Size = new Size(230, 25);
            txtPassword.UseSystemPasswordChar = true;

            Button btnLogin = new Button
            {
                Text = "Login",
                Location = new Point(145, 170),
                Size = new Size(110, 35)
            };
            btnLogin.Click += Login_Click;

            Controls.AddRange(new Control[]
            {
                title, lblUsername, txtUsername, lblPassword, txtPassword, btnLogin
            });

            AcceptButton = btnLogin;
        }

        private void Login_Click(object sender, EventArgs e)
        {
            // Sample credentials for this lab application.
            if (txtUsername.Text.Trim() == "admin" &&
                txtPassword.Text == "1234")
            {
                MainForm menu = new MainForm();
                menu.FormClosed += (s, args) => this.Show();

                Hide();
                menu.Show();
            }
            else
            {
                MessageBox.Show(
                    "Incorrect username or password.",
                    "Login failed",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtPassword.Clear();
                txtPassword.Focus();
            }
        }
    }

    public class MainForm : Form
    {
        public MainForm()
        {
            Text = "Menu Form";
            ClientSize = new Size(430, 250);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            Label title = new Label
            {
                Text = "MENU FORM",
                Font = new Font("Arial", 16, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(20, 25),
                Size = new Size(390, 35)
            };

            Button btnBicycle = new Button
            {
                Text = "Bicycle",
                Font = new Font("Arial", 11),
                Location = new Point(45, 100),
                Size = new Size(150, 55)
            };

            Button btnMushroom = new Button
            {
                Text = "Mushroom",
                Font = new Font("Arial", 11),
                Location = new Point(235, 100),
                Size = new Size(150, 55)
            };

            btnBicycle.Click += (s, e) => OpenChild(new BicycleForm());
            btnMushroom.Click += (s, e) => OpenChild(new MushroomForm());

            Controls.AddRange(new Control[] { title, btnBicycle, btnMushroom });
        }

        private void OpenChild(Form child)
        {
            Hide();
            child.ShowDialog(this);

            // The child form sets this property when Logout is clicked.
            bool logout = child is BicycleForm bicycle && bicycle.LogoutRequested;
            if (child is MushroomForm mushroom && mushroom.LogoutRequested)
                logout = true;

            if (logout)
                Close();       // LoginForm is shown by its FormClosed handler.
            else
                Show();        // Otherwise return to the menu.
        }
    }

    public class BicycleForm : Form
    {
        private readonly TextBox txtStart = new TextBox();
        private readonly TextBox txtEnd = new TextBox();
        private readonly TextBox txtTotal = new TextBox();

        public bool LogoutRequested { get; private set; }

        public BicycleForm()
        {
            Text = "Bicycle Rental";
            ClientSize = new Size(470, 360);
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            Label title = new Label
            {
                Text = "BICYCLE RENTAL",
                Font = new Font("Arial", 15, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(20, 20),
                Size = new Size(430, 35)
            };

            Label lblStart = new Label
            {
                Text = "Starting hour (0-23):",
                Location = new Point(35, 80),
                Size = new Size(165, 25)
            };
            txtStart.Location = new Point(210, 77);
            txtStart.Size = new Size(210, 25);

            Label lblEnd = new Label
            {
                Text = "Ending hour (1-24):",
                Location = new Point(35, 120),
                Size = new Size(165, 25)
            };
            txtEnd.Location = new Point(210, 117);
            txtEnd.Size = new Size(210, 25);

            Button btnCalculate = new Button
            {
                Text = "Calculate Total",
                Location = new Point(145, 165),
                Size = new Size(170, 38)
            };
            btnCalculate.Click += Calculate_Click;

            Label lblTotal = new Label
            {
                Text = "Total (RWF):",
                Font = new Font("Arial", 10, FontStyle.Bold),
                Location = new Point(35, 225),
                Size = new Size(165, 28)
            };
            txtTotal.Location = new Point(210, 222);
            txtTotal.Size = new Size(210, 28);
            txtTotal.ReadOnly = true;
            txtTotal.BackColor = Color.White;

            Button btnLogout = new Button
            {
                Text = "Logout",
                Location = new Point(165, 285),
                Size = new Size(130, 35)
            };
            btnLogout.Click += (s, e) =>
            {
                LogoutRequested = true;
                Close();
            };

            Controls.AddRange(new Control[]
            {
                title, lblStart, txtStart, lblEnd, txtEnd,
                btnCalculate, lblTotal, txtTotal, btnLogout
            });

            AcceptButton = btnCalculate;
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtStart.Text, out int start) ||
                !int.TryParse(txtEnd.Text, out int end))
            {
                MessageBox.Show(
                    "Enter whole-number hours only. Decimal values are not accepted.",
                    "Invalid input",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (start < 0 || start > 23 || end < 1 || end > 24)
            {
                MessageBox.Show(
                    "Starting hour must be 0-23 and ending hour must be 1-24.",
                    "Invalid time",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (start >= end)
            {
                MessageBox.Show(
                    "The starting hour must be less than the ending hour.",
                    "Invalid rental period",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            int total = 0;

            // Charge each one-hour interval from start up to, but not including, end.
            for (int hour = start; hour < end; hour++)
            {
                int rate;

                if (hour < 7 || hour >= 21)
                    rate = 500;
                else if (hour < 14 || hour >= 19)
                    rate = 1000;
                else
                    rate = 1500;

                total += rate;
            }

            txtTotal.Text = total.ToString("N0");
        }
    }

    public class MushroomForm : Form
    {
        private readonly TextBox txtMushroom = new TextBox();

        public bool LogoutRequested { get; private set; }

        public MushroomForm()
        {
            Text = "Mushroom Identification";
            ClientSize = new Size(490, 260);
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            Label title = new Label
            {
                Text = "MUSHROOM IDENTIFICATION",
                Font = new Font("Arial", 14, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(20, 20),
                Size = new Size(450, 35)
            };

            Label lblMushroom = new Label
            {
                Text = "Mushroom type:",
                Location = new Point(30, 85),
                Size = new Size(125, 28)
            };

            txtMushroom.Location = new Point(160, 82);
            txtMushroom.Size = new Size(290, 28);
            txtMushroom.ReadOnly = true;
            txtMushroom.BackColor = Color.White;

            Button btnIdentify = new Button
            {
                Text = "Identify",
                Location = new Point(85, 150),
                Size = new Size(125, 38)
            };
            btnIdentify.Click += Identify_Click;

            Button btnLogout = new Button
            {
                Text = "Logout",
                Location = new Point(265, 150),
                Size = new Size(125, 38)
            };
            btnLogout.Click += (s, e) =>
            {
                LogoutRequested = true;
                Close();
            };

            Controls.AddRange(new Control[]
            {
                title, lblMushroom, txtMushroom, btnIdentify, btnLogout
            });
        }

        private bool AskYesNo(string question)
        {
            return MessageBox.Show(
                question,
                "Mushroom question",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes;
        }

        private void Identify_Click(object sender, EventArgs e)
        {
            string result;

            // Question 1: ring
            bool hasRing = AskYesNo("Does your mushroom have a ring?");

            if (hasRing)
            {
                // Ring-bearing mushrooms in the lab: Agaric, Amanite, Coprin.
                bool hasConvexCup = AskYesNo(
                    "Does your mushroom have a convex cup?");

                if (hasConvexCup)
                {
                    // Agaric grows in meadows; Amanite grows in forests.
                    bool growsInForest = AskYesNo(
                        "Does your mushroom grow in a forest?");

                    result = growsInForest
                        ? "Amanite tue-mouche"
                        : "Agaric Jaunissant";
                }
                else
                {
                    result = "Coprin chevelu";
                }
            }
            else
            {
                // Cepe is the only mushroom in the lab with pores, not gills.
                bool hasGills = AskYesNo(
                    "Does your mushroom have gills?");

                if (!hasGills)
                {
                    result = "Cepe de bordeau";
                }
                else
                {
                    bool hasConvexCup = AskYesNo(
                        "Does your mushroom have a convex cup?");

                    result = hasConvexCup ? "Pied bleu" : "Girolle";
                }
            }

            txtMushroom.Text = result;
        }
    }
}
